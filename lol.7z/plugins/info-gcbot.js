let handler = async (m, { conn }) => {
  let text = 'ICSF Team\nhttps://chat.whatsapp.com/HwLGl4MrayN44bstlNCpdn'
  m.reply(text)
}

handler.command = /^(gcbot)$/i;
handler.private = false;
module.exports = handler;