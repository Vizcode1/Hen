let handler = async (m, {conn}) => { 
conn.reply(m.chat, `uwu = Owner 1 jam
3❤️ = Premium 1 jam
3💵 = 10k money bot
3👑 = Helper 1 hari
3💰 = 10k xp bot
3✅ = 5 spin
3❌ = ban 1 jam

uwuwu = Owner 1 hari
5❤️ = Premium 1 hari
5💵 = 50k money bot
5👑 = Helper 3 hari
5💰 = 50k xp bot
5✅ = 20 spin
5❌ = ban 1 hari

uwuwuwu = Owner 1 minggu
7❤️ = Premium 1 minggu
7💵 = 100k money bot
7👑 = Helper 1 minggu
7💰 = 100k xp bot
7✅ = 50 spin
7❌ = ban permanen

wuw = harus Donasi or ban`) }

handler.help = ['hadiahspin ']
handler.tags = ['game']
handler.command = /^hadiahspin$/

module.exports = handler