async function before(m, {
    isOwner,
    conn
}) {
    if (m.isGroup) return    
    if (!m.text) return
    if (!m.text) {
    conn.sendPresenceUpdate("composing", m.chat)
    } else {
    conn.sendPresenceUpdate("composing", m.chat)
    }
}

module.exports = {
    before,
}